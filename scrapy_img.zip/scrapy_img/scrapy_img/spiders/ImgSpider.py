# -*- coding: utf-8 -*-
import scrapy
from ..items import ScrapyImgItem

class ImgspiderSpider(scrapy.Spider):
    name = 'ImgSpider'
#    allowed_domains = ['http://automationpractice.com/index.php?id_product=2']
    #start_urls = ['http://automationpractice.com/index.php?id_product=2&controller=product']
    start_urls = ['https://pixabay.com/photos/search/elephants/']

    def parse(self, response):
        item = ScrapyImgItem()
        img_urls = []
        a_selectors = response.xpath("//div[@class='item']/a/img")
        print("Length of selector is "+str(len(a_selectors)))
        for img in a_selectors:
            img_src = img.xpath("@src").extract_first()
            img_src2 = img.xpath("@data-lazy-srcset").extract_first()
            
            if img_src2 == "" or img_src2 == None:
                print(img_src)
                img_urls.append(img_src)
                print("Appending img src")
            else:
                print(img_src2)
                str1 = img_src2.split(",")
                newStr = str1[0].replace(" 1x","")
                print("String is "+newStr)
                img_urls.append(newStr)
        
        next_page_url = response.xpath('//a[contains(text(), "Next")]/@href').extract_first()
        print("Next page is "+next_page_url)
        item["image_urls"] = img_urls
        yield item
        if next_page_url:
            next_page_url = response.urljoin(next_page_url)
            yield scrapy.Request(url=next_page_url, callback=self.parse)
