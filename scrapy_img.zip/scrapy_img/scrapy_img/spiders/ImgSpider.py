# -*- coding: utf-8 -*-
import scrapy
from ..items import ScrapyImgItem
import shutil
import os, glob

def makeFolders():
    #default = 'C:/Users/P1318214/Desktop/Images/full/'
    #elephant = 'C:/Users/P1318214/Desktop/Images/full/elephant'
    
    elephant = './images/elephant'
    lion = './images/lion'
    zebra = './images/zebra'
    monkey = './images/monkey'
    giraffe = './images/giraffe'
    deer = './images/deer'
    horse = './images/horse'
    
    if not os.path.isdir(elephant):
        os.makedirs(elephant)
        
    if not os.path.isdir(lion):
        os.makedirs(lion)
        
    if not os.path.isdir(zebra):
        os.makedirs(zebra)
        
    if not os.path.isdir(monkey):
        os.makedirs(monkey)
        
    if not os.path.isdir(giraffe):
        os.makedirs(giraffe)
        
    if not os.path.isdir(deer):
        os.makedirs(deer)
        
    if not os.path.isdir(horse):
        os.makedirs(horse)
        
def splitString(urlName):
        result = ""
        strArray = urlName.split("/")
        result = strArray[-1]
        result = result.replace(".jpg","")
        result = result.replace(".png","")
        return result


makeFolders()


class ImgspiderSpider(scrapy.Spider):
    name = 'ImgSpider'
    
#    allowed_domains = ['http://automationpractice.com/index.php?id_product=2']
    #start_urls = ['http://automationpractice.com/index.php?id_product=2&controller=product']
    start_urls = ['https://pixabay.com/photos/search/elephants/',
                  'https://pixabay.com/photos/search/lions/',
                  'https://pixabay.com/photos/search/zebras/',
                  'https://pixabay.com/photos/search/monkeys/',
                  'https://pixabay.com/photos/search/giraffe/',
                  'https://pixabay.com/photos/search/deer/',
                  'https://pixabay.com/photos/search/horse/',]
    pageCount = 15
    curPage = 0
    
    def parse(self, response):
        item = ScrapyImgItem()
        img_urls = []
        img_names = []
        
        a_selectors = response.xpath("//div[@class='item']/a/img")
        for img in a_selectors:
            img_src = img.xpath("@src").extract_first()
            img_src2 = img.xpath("@data-lazy-srcset").extract_first()
            
            if img_src2 == "" or img_src2 == None:
                #print(img_src)
                img_urls.append(img_src)
                #print("Appending img src")
                img_names.append(splitString(img_src))
            else:
                #print(img_src2)
                str1 = img_src2.split(",")
                newStr = str1[0].replace(" 1x","")
                #print("String is "+newStr)
                img_urls.append(newStr)
                img_names.append(splitString(newStr))
            
            
        next_page_url = response.xpath('//a[contains(text(), "Next")]/@href').extract_first()
        #print("Next page is "+next_page_url)
        item["image_urls"] = img_urls
        item["image_names"] = img_names
        if "elephant" in response.url:
                item["category"] = "elephant"
        if "lion" in response.url:
                item["category"] = "lion"
        if "zebra" in response.url:
                item["category"] = "zebra"
        if "monkey" in response.url:
                item["category"] = "monkey"
        if "giraffe" in response.url:
                item["category"] = "giraffe"
        if "deer" in response.url:
                item["category"] = "deer"
        if "horse" in response.url:
                item["category"] = "horse"
        
        yield item
        #if self.curPage <= self.pageCount and next_page_url: 
            #next_page_url = response.urljoin(next_page_url)
            #yield scrapy.Request(url=next_page_url, callback=self.parse)
            #self.curPage += 1
        #else:
            #self.curPage = 0