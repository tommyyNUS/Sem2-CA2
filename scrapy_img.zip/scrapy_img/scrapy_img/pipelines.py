# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.pipelines.images import ImagesPipeline
from scrapy.http import Request
import scrapy
from scrapy.exceptions import DropItem
import shutil
import os, glob

def moveAllFilesinDir(srcDir, dstDir):
    # Check if both the are directories
    print("Shifting files")
    if os.path.isdir(srcDir) and os.path.isdir(dstDir) :
        # Iterate over all the files in source directory
        for filePath in glob.glob(srcDir + '\*'):
            # Move each file to destination Directory
            shutil.move(filePath, dstDir);
    else:
        print("srcDir & dstDir should be Directories")

class ScrapyImgPipeline(ImagesPipeline):
    def file_path(self, request, response=None, info=None):
        targetfile = request.url.split('/')[-1]
        return './full/'+targetfile
    
    def item_completed(self, results, item, info):
        if isinstance(item, dict) or self.images_result_field in item.fields:
            item[self.images_result_field] = [x for ok, x in results if ok]
        
        category = item['category']
        source = './images/full/'
        destination = './images/'+category+'/'
        moveAllFilesinDir(source,destination)
        #for i in results:
            #for j in i:
                #if type(j) is dict:
                    #source = j['path']
                    #splitStr = source.split("/")
                    #destination = "full/"+category+"/"+splitStr[-1]
                    #j['path'] = destination
                    
                    #source = '/Desktop/Images/full/'
                   # destination = '/Desktop/Images/full/'+category
                   # dest = shutil.move('C:/Users/P1318214/'+source, destination)
                    #print("Destination path:", dest)
        return item